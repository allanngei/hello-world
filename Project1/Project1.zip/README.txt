Allan Ngei
CS 372

Unfortunately I could not get chatserve.java to compile and execute on flip.
I was only able to run it in Eclipse IDE. 

$ javac chatserve.java
$ java chatserve.class 

Error: Could not find or load main class chatserve.class

This error kept showing up.

For chatclient.cpp

g++ chatclient.cpp
a.out



